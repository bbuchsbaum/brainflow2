---
name: ui-design-discipline
description: Use when auditing, creating, or changing frontend UI themes, design tokens, component libraries, Storybook, visual consistency rules, Tailwind/CSS themes, or lint guardrails. Establishes a standard UI source of truth, inspects existing UI, proposes a path forward, and prevents style drift.
---

# UI Design Discipline Skill

You are the repository's UI consistency steward. Your job is to make UI decisions explicit, central, documented, reusable, and enforceable.

Use this skill when the user asks about UI consistency, theming, design tokens, component variants, Storybook, visual audits, Tailwind/CSS discipline, component libraries, layout primitives, lint rules, or when a UI change risks visual drift.

## Core principle

Push decisions up the stack:

**tokens → utilities/theme → components → composition primitives/templates → documentation → lint/CI guardrails**

Never solve repeated UI drift by copying one-off markup unless you also identify the shared primitive or rule that would prevent the drift from returning.

## Standard source-of-truth locations

Prefer these locations unless the repository already has an equivalent convention:

- `docs/design-system/ui-contract.md` — canonical UI contract and review rules.
- `docs/design-system/component-index.md` — available components, variants, sizes, and usage rules.
- `docs/design-system/tokens.md` — token naming, values, and semantic mapping.
- `docs/design-system/patterns.md` — repeated layouts such as rows, cards, lists, empty states, forms, and page shells.
- `docs/design-system/decisions.md` — dated design-system decisions and migrations.
- `src/styles/tokens.css`, `src/app/globals.css`, `src/index.css`, or `packages/ui/tokens/*` — token implementation.
- `src/components/ui/*`, `components/ui/*`, `packages/ui/src/*`, or the repo's established UI package — component wrappers.
- `.storybook/*` plus `*.stories.*` — component documentation and visual examples.
- `eslint`, `stylelint`, pre-commit, and CI configs — mechanical enforcement.

When another standard location already exists, map it in the authority map and do not create competing documents.

## First action: build a UI authority map

Before changing UI code, inspect the repo and answer:

1. What framework is used? React, Next, Remix, Vue, Svelte, Angular, Astro, native CSS, Tailwind, CSS modules, CSS-in-JS, etc.
2. Where are tokens or theme values defined?
3. Where are shared UI components defined?
4. Where are layout/composition primitives defined?
5. Where are docs, mockups, Figma references, Storybook, or screenshots kept?
6. What lint/test/build scripts already exist?
7. Which package manager is already used?

Useful bundled references:

- `references/discovery-map.md` — exact files and folders to inspect.
- `references/ui-audit-playbook.md` — audit checklist and scoring.
- `references/style-questionnaire.md` — questions to ask when no UI system exists.
- `references/design-system-contract.md` — source-of-truth rules.
- `references/storybook-playbook.md` — Storybook setup and story generation guidance.
- `references/linting-guardrails.md` — lint and CI guardrails.
- `references/migration-roadmap.md` — how to move from ad hoc UI to a system.
- `references/output-templates.md` — response formats.

Optional bundled scripts:

- `scripts/ui_inventory.py` — scans a repo and writes `.ui-discipline/audit-report.md` and `.ui-discipline/audit-report.json`.
- `scripts/create_ui_contract.py` — creates `docs/design-system/ui-contract.md` from the template when missing.

Run scripts only when appropriate for the environment and after checking that Python is available. Do not run scripts that would overwrite existing files without preserving or reviewing them first.

## Existing UI workflow

When a UI already exists, do not immediately replace it. Audit it and propose a path forward.

1. **Inventory**
   - Use repo search and, when useful, `scripts/ui_inventory.py`.
   - Identify existing tokens, theme config, UI wrappers, stories, docs, and lint rules.
   - Note all authoritative sources and conflicts.

2. **Classify maturity**
   - `Mature`: tokens, components, docs/stories, and guardrails exist.
   - `Emerging`: some shared components or tokens exist, but drift and undocumented rules remain.
   - `Ad hoc`: UI is mostly one-off classes, inline styles, raw values, and repeated bespoke patterns.
   - `No UI`: no frontend app or no visible styling conventions.

3. **Find drift symptoms**
   Look for:
   - raw hex colors or one-off CSS values outside token files;
   - inconsistent button/link/input/card variants;
   - arbitrary Tailwind values that should be tokens;
   - duplicated row/list/card markup;
   - multiple icon sizes for the same semantic role;
   - inconsistent focus rings, disabled states, and hover states;
   - layout spacing that differs between similar surfaces;
   - variants implemented by class concatenation instead of component props;
   - missing stories for shared primitives.

4. **Recommend path forward**
   Choose one primary strategy:
   - **Stabilize**: preserve existing design, document it, and add guardrails.
   - **Consolidate**: extract repeated UI into shared components or layout primitives.
   - **Tokenize**: move raw values into semantic tokens and update utilities/theme.
   - **Document**: create or update the UI contract and Storybook stories.
   - **Enforce**: add lint/CI checks after documenting allowed exceptions.
   - **Redesign**: only when the user explicitly wants a design direction change.

5. **Implement carefully**
   - Prefer existing components over new ones.
   - Prefer semantic tokens over raw values.
   - Prefer component props over utility-level styling for repeated patterns.
   - Add or update stories for any shared component changed.
   - Add lint rules only after the source of truth exists.
   - Run available lint/test/typecheck/storybook build scripts when feasible.

## No UI workflow

When no meaningful UI style exists, ask a small set of questions before generating code. Ask no more than 6 questions at once.

Start with this default prompt:

> I do not see a stable UI system yet. Do you want to start from a preset direction or define one from scratch? Preset examples: Linear-inspired minimal productivity, Vercel-inspired monochrome developer tool, Stripe-inspired polished SaaS, calm enterprise dashboard, editorial/content-heavy, playful consumer app. I will use these only as broad style directions, not as exact copies.

Then ask about:

- product type and primary users;
- brand personality: calm, premium, playful, technical, editorial, bold, warm;
- density: compact, balanced, spacious;
- color posture: neutral-first, accent-led, colorful, dark-first;
- typography: system, geometric, editorial, mono-supported;
- component needs: dashboard, forms, tables, cards, navigation, marketing pages;
- accessibility constraints and motion preference;
- implementation stack and package manager.

After the answers, create a draft `docs/design-system/ui-contract.md`, initial tokens, and 3–5 starter components before broad screen work.

## Required output format for audits

When auditing or proposing UI discipline, respond with:

1. **UI authority map** — where the current source of truth lives.
2. **Maturity assessment** — mature, emerging, ad hoc, or no UI.
3. **Consistency risks** — concrete drift risks found.
4. **Recommended path** — stabilize, consolidate, tokenize, document, enforce, or redesign.
5. **First implementation slice** — the smallest useful change set.
6. **Guardrails** — lint, Storybook, docs, tests, or review rules to prevent recurrence.
7. **Verification** — commands to run and what should pass.

For implementation tasks, add a short **Changed files** section and explain why each new file exists.

## Guardrail rules

Follow these rules unless the repository's existing UI contract says otherwise:

- Components should read semantic tokens, not raw hex colors or one-off pixel values.
- Shared components define visual variants. Screens consume variants.
- Repeated row/list/card/page-shell structures should become composition primitives.
- Tailwind arbitrary values are allowed only for rare, documented exceptions.
- Inline `style={{ ... }}` is allowed only for truly dynamic values that cannot be expressed as tokens or classes.
- A new component variant needs a story, a usage rule, and at least one example state.
- Do not add a new UI dependency without explaining why existing tools are insufficient.
- Do not copy exact proprietary brand systems. Use named products only as broad inspiration when the user requests it.
- Do not make broad visual redesigns when the user only asked for consistency.

## Storybook discipline

If Storybook exists, add stories for changed or newly extracted components. If it does not exist, propose setup rather than forcing it. For a first pass, stories should cover:

- default, hover/focus-relevant, disabled, loading, and destructive/critical states where applicable;
- each supported `variant` and `size`;
- light/dark themes if the repo supports them;
- common composition examples, such as list rows, page headers, and empty states.

## Lint discipline

Lint guardrails should start as warnings unless the repo already has strong enforcement. Common checks:

- no raw hex colors outside token files;
- no hardcoded design-system spacing/radii values outside token files;
- no ad hoc button-like elements when a `Button` exists;
- no arbitrary Tailwind values without an allowlist comment;
- no inline style objects for static values;
- require stories for files under shared UI component directories.

## When editing code

- Determine the package manager from lockfiles before suggesting commands.
- Do not overwrite existing design docs; update or append with a dated decision.
- Keep changes small and reviewable.
- Prefer codemods or narrow search/replace for systematic token migrations.
- After changes, run the repo's most relevant checks, usually lint, typecheck, tests, and Storybook build if present.

## Final review rubric

A UI change is acceptable when:

- the design decision is represented at the highest reasonable layer;
- a future developer can find the rule in the standard location;
- shared UI uses component props or composition primitives rather than copied markup;
- tokens and variants are named semantically;
- Storybook or docs show the intended result;
- lint/CI or review checklist catches the most likely regressions.
